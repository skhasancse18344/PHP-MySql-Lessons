<!DOCTYPE html>
<head>
    <title>
        PHP Syntax
    </title>
</head>
<html>
<body>
    
    <?php
    echo "Hello World <hr/>";
    //comment
    
    #Comment
    /*
    Multi line Comment Block
    Multi line Comment Block
    Multi line Comment Block
    */
    //Comment contained inside code
    
    $x=10 /* +5 */+20;
    echo $x;
    echo "<hr/>";
    
    //Function Is not case sensitive
    ECHO "Text Sample 1  <hr/>";
    echo  "Text Sample 2  <hr/>";
    ECho "Text Sample 3  <hr/>";
    
    //Variable is case sensitive
    $car = "volvo";
        echo "My car is a" . $car . "<br>";
        echo "My car is a" . $CAR . "<br>";
        echo "My car is a" . $CAR . "<br>";
    ?>
</body>
</html>